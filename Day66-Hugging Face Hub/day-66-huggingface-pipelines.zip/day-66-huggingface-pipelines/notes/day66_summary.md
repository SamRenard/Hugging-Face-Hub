# Gün 66 - Konspekt: Hugging Face Hub

## Qısa xülasə

1. Hugging Face Hub modellərin, datasetlərin və demoların yerləşdiyi Git əsaslı platformadır, hər model ayrıca bir repodur.
2. Model `istifadəçi/ad` identifikatoru ilə çağırılır və çəkilər, `config.json` və tokenizer fayllarından ibarətdir.
3. Transformers kitabxanası modeli Hub-dan yükləyib işlədir, `pipeline()` isə bütün axını bir çağırışa yığır.
4. Pipeline üç addımdır: preprocessing (tokenizer), model və postprocessing (logits → label və score).
5. Həmişə `model=` adını açıq yazın, çünki default model versiyadan versiyaya dəyişə bilər.
6. Transformers v5-də `summarization`, `question-answering`, `translation` və `text2text-generation` pipeline-ları silindi, əvəzinə `AutoModel` ilə `generate()` və ya `text-generation` ilə chat model istifadə olunur.
7. `.safetensors` formatı təhlükəsizdir, `.bin` (pickle) isə yükləmə zamanı kod icra edə bilər, ona görə yeni torch tələb olunur.
8. Yüklənən fayllar `~/.cache/huggingface` qovluğunda keşlənir, ona görə ikinci işə salma sürətlidir.

## Əsas axın

```
mətn → tokenizer → input_ids → model → logits → softmax → {label, score}
```

| Tapşırıq | Model | v5-də necə |
|---|---|---|
| Sentiment | `distilbert-base-uncased-finetuned-sst-2-english` | `pipeline()` |
| NER | `dslim/bert-base-NER` | `pipeline()` |
| Summarization | `sshleifer/distilbart-cnn-12-6` | `AutoModelForSeq2SeqLM` |
| QA | `distilbert-base-cased-distilled-squad` | `AutoModelForQuestionAnswering` |
| Text generation | `openai-community/gpt2` | `pipeline()` |

## Açar terminlər

- **Hub** - modellərin saxlandığı platforma
- **Pipeline** - tokenizer, model və postprocessing-i birləşdirən çağırış
- **Tokenizer** - mətni token nömrələrinə çevirir
- **Logits** - modelin xam balları
- **Checkpoint** - təlim olunmuş çəkilər
- **`AutoModel`** - model sinfini avtomatik seçən sinif
- **`aggregation_strategy`** - NER-də söz parçalarını bütöv varlığa birləşdirir
- **safetensors** - təhlükəsiz çəki formatı

## Tipik səhvlər

- Köhnə (v4) tutorialları v5-də işlətmək, `KeyError: Unknown task summarization` alınır.
- `model=` yazmayıb default modelə güvənmək.
- GPU olmayanda `device="cuda"` vermək.
- Tokenizer və modeli fərqli checkpoint-lərdən götürmək.
