"""Registry, runner, report formatting and CLI, all with fake models (no downloads)."""

import contextlib
import io
import json
import os
import subprocess
import sys
import tempfile

import numpy as np
import pytest

from hf_tasks import TASKS, TaskResult, TaskSpec, get_task, run_all, run_task
from hf_tasks.cli import main, parse_overrides
from hf_tasks.report import describe, to_json, to_markdown, write_reports

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")


def fake_spec(key="fake", load=None, run=None):
    return TaskSpec(
        key=key,
        title=f"Fake {key}",
        pipeline_task="sentiment-analysis",
        model_id="org/default-model",
        example={"texts": ["text"]},
        load=load or (lambda model, device: (model, device)),
        run=run or (lambda loaded, example: [{"label": "POSITIVE", "score": 0.9}]),
    )


def capture(fn, *args, **kwargs):
    buffer = io.StringIO()
    with contextlib.redirect_stdout(buffer):
        code = fn(*args, **kwargs)
    return code, buffer.getvalue()


# ------------------------------- registry ---------------------------------- #
def test_registry_has_the_five_tasks_in_order():
    assert list(TASKS) == ["sentiment", "ner", "summarization", "qa", "generation"]
    for spec in TASKS.values():
        assert "/" in spec.model_id and spec.example and callable(spec.load) and callable(spec.run)


def test_tasks_removed_from_pipeline_in_v5_use_the_auto_classes():
    direct = {k for k, spec in TASKS.items() if not spec.uses_pipeline}
    assert direct == {"summarization", "qa"}
    assert {s.pipeline_task for s in TASKS.values() if s.uses_pipeline} == {"sentiment-analysis", "ner", "text-generation"}


def test_get_task_error_lists_choices():
    with pytest.raises(KeyError):
        get_task("translation")
    assert get_task("qa") is TASKS["qa"]


def test_importing_the_package_does_not_import_transformers_or_torch():
    code = "import sys, hf_tasks; assert 'transformers' not in sys.modules and 'torch' not in sys.modules"
    subprocess.run([sys.executable, "-c", code], cwd=ROOT, check=True)


# -------------------------------- runner ------------------------------------ #
def test_run_task_success_passes_model_and_device_and_measures_time():
    ticks = iter([10.0, 12.5, 13.0])  # start, after load, after run
    result = run_task(fake_spec(), device="cuda", model_id="org/other", clock=lambda: next(ticks))
    assert result.ok and result.error is None
    assert result.model_id == "org/other"
    assert result.load_seconds == pytest.approx(2.5) and result.run_seconds == pytest.approx(0.5)
    assert result.output == [{"label": "POSITIVE", "score": 0.9}]


def test_load_failure_is_captured_and_run_is_skipped():
    called = []

    def bad_load(model, device):
        raise OSError("model not found")

    result = run_task(fake_spec(load=bad_load, run=lambda *a: called.append(1)))
    assert not result.ok and "OSError: model not found" in result.error and not called


def test_run_failure_is_captured():
    def bad_run(loaded, example):
        raise RuntimeError("out of memory")

    result = run_task(fake_spec(run=bad_run))
    assert not result.ok and "RuntimeError: out of memory" in result.error


def test_keyboard_interrupt_is_not_swallowed():
    def interrupted(model, device):
        raise KeyboardInterrupt

    with pytest.raises(KeyboardInterrupt):
        run_task(fake_spec(load=interrupted))


def test_run_all_isolates_failures_keeps_order_and_reports_progress():
    def boom(model, device):
        raise ValueError("boom")

    registry = {"a": fake_spec("a"), "b": fake_spec("b", load=boom), "c": fake_spec("c")}
    seen = []
    results = run_all(tasks=registry, on_result=lambda n, total, r: seen.append((n, total, r.key)))
    assert [r.key for r in results] == ["a", "b", "c"]
    assert [r.ok for r in results] == [True, False, True]
    assert seen == [(1, 3, "a"), (2, 3, "b"), (3, 3, "c")]


def test_run_all_selection_and_overrides():
    registry = {"a": fake_spec("a"), "b": fake_spec("b")}
    results = run_all(["b"], registry, overrides={"b": "org/custom"})
    assert [r.key for r in results] == ["b"] and results[0].model_id == "org/custom"
    with pytest.raises(KeyError):
        run_all(["zzz"], registry)


# ------------------------------- formatting --------------------------------- #
def test_describe_each_task_with_documented_output_shapes():
    sentiment = describe(TASKS["sentiment"], [{"label": "POSITIVE", "score": 0.9998}] * 3)
    assert len(sentiment) == 3 and "POSITIVE (0.9998)" in sentiment[0] and "Hugging Face Hub" in sentiment[0]

    entity = {"entity_group": "ORG", "score": 0.99, "word": "Hugging Face", "start": 0, "end": 12}
    ner = describe(TASKS["ner"], [[entity], []])
    assert any("ORG" in line and "Hugging Face" in line for line in ner) and "(no entities)" in ner[-1]

    assert describe(TASKS["summarization"], [{"summary_text": "A short summary."}]) == ["A short summary."]

    qa = describe(TASKS["qa"], {"answer": "Transformers", "score": 0.8, "start": 4, "end": 16})
    assert qa[0].startswith("Q: ") and "A: Transformers" in qa[1]

    assert describe(TASKS["generation"], [{"generated_text": "The Hub is a place where..."}]) == ["The Hub is a place where..."]


def test_describe_falls_back_for_unexpected_shapes():
    for key in TASKS:
        lines = describe(TASKS[key], None)
        assert lines[0].startswith("(unexpected output format)")


def test_json_report_handles_numpy_values():
    result = TaskResult("k", "Title", "org/m", True, True, 1.23456, 0.98765,
                        output=[{"score": np.float32(0.5), "vec": np.array([1, 2])}], lines=["x"])
    data = json.loads(to_json([result], {"python": "3.12"}))
    row = data["results"][0]
    assert row["output"][0]["score"] == 0.5 and row["output"][0]["vec"] == [1, 2]
    assert row["load_seconds"] == 1.235 and data["environment"]["python"] == "3.12"


def test_markdown_report_shows_success_and_failure():
    ok = TaskResult("a", "Alpha", "org/a", True, True, 1.0, 0.1, lines=["fine"])
    bad = TaskResult("b", "Beta", "org/b", False, False, error="OSError: no network")
    text = to_markdown([ok, bad], {"python": "3.12", "transformers": "5.0", "torch": "2.6", "date": "2026-10-14"})
    assert "| Alpha | `org/a` | pipeline() | 1.00 | 0.10 | ok |" in text
    assert "| Beta | `org/b` | Auto classes | 0.00 | 0.00 | FAILED |" in text
    assert "FAILED: OSError: no network" in text and "fine" in text


def test_unicode_output_is_written_as_utf_8():
    result = TaskResult("a", "Alpha", "org/a", True, True, lines=["caf\u00e9 \u2014 \u0259"])
    with tempfile.TemporaryDirectory() as folder:
        json_path, md_path = write_reports([result], {}, folder)
        assert "\u0259" in open(md_path, encoding="utf-8").read()
        assert json.load(open(json_path, encoding="utf-8"))["results"][0]["lines"] == ["caf\u00e9 \u2014 \u0259"]


# ---------------------------------- CLI -------------------------------------- #
def test_parse_overrides():
    assert parse_overrides(["qa=org/model", "ner=a/b"], ["qa", "ner"]) == {"qa": "org/model", "ner": "a/b"}
    for bad in (["qa"], ["qa="], ["nope=x/y"]):
        with pytest.raises(ValueError):
            parse_overrides(bad, ["qa", "ner"])


def test_cli_runs_everything_and_writes_reports():
    registry = {"a": fake_spec("a"), "b": fake_spec("b")}
    with tempfile.TemporaryDirectory() as folder:
        code, output = capture(main, ["--output-dir", folder], registry)
        assert code == 0 and "All 2 tasks succeeded" in output
        assert sorted(os.listdir(folder)) == ["results.json", "results.md"]


def test_cli_exit_code_is_one_when_a_task_fails_but_reports_are_still_written():
    def boom(model, device):
        raise OSError("offline")

    registry = {"a": fake_spec("a"), "b": fake_spec("b", load=boom)}
    with tempfile.TemporaryDirectory() as folder:
        code, output = capture(main, ["--output-dir", folder], registry)
        assert code == 1 and "1 task(s) failed: b" in output and "OSError: offline" in output
        assert "FAILED" in open(os.path.join(folder, "results.md"), encoding="utf-8").read()


def test_cli_task_selection_override_and_device():
    seen = {}

    def load(model, device):
        seen["args"] = (model, device)
        return None

    registry = {"a": fake_spec("a", load=load), "b": fake_spec("b")}
    with tempfile.TemporaryDirectory() as folder:
        code, _ = capture(main, ["a", "--device", "cuda", "--model", "a=org/x", "--output-dir", folder], registry)
        data = json.load(open(os.path.join(folder, "results.json"), encoding="utf-8"))
    assert code == 0 and seen["args"] == ("org/x", "cuda") and [r["key"] for r in data["results"]] == ["a"]


def test_cli_list_and_bad_arguments():
    code, output = capture(main, ["--list"])
    assert code == 0 and all(key in output for key in TASKS)
    for bad in (["translation"], ["--model", "qa"], ["--model", "nope=a/b"]):
        with pytest.raises(SystemExit):
            main(bad, {"qa": fake_spec("qa")})
