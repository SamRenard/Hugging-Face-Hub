"""Opt-in tests that download the real models (about 3 GB) and run them.

    RUN_HF_INTEGRATION=1 python -m pytest tests/test_integration.py -v

Skipped by default, so the normal test run stays fast and works offline.
"""

import os

import pytest

pytest.importorskip("transformers")
pytest.importorskip("torch")

pytestmark = pytest.mark.skipif(
    os.environ.get("RUN_HF_INTEGRATION") != "1", reason="set RUN_HF_INTEGRATION=1 to download and run real models"
)

from hf_tasks import TASKS, run_task  # noqa: E402


def run(key):
    result = run_task(TASKS[key])
    assert result.ok, result.error
    return result.output


def test_sentiment():
    labels = [r["label"] for r in run("sentiment")]
    assert labels[0] == "POSITIVE" and labels[1] == "NEGATIVE"


def test_ner_finds_entities_in_every_sentence():
    outputs = run("ner")
    assert len(outputs) == 2 and all(len(entities) > 0 for entities in outputs)


def test_summarization_is_shorter_than_the_input():
    summary = run("summarization")[0]["summary_text"]
    assert 0 < len(summary) < len(TASKS["summarization"].example["text"])


def test_question_answering_finds_the_library():
    answer = run("qa")
    assert "transformers" in answer["answer"].lower() and 0 < answer["score"] <= 1


def test_text_generation_continues_the_prompt():
    text = run("generation")[0]["generated_text"]
    prompt = TASKS["generation"].example["prompt"]
    assert text.startswith(prompt) and len(text) > len(prompt)
