"""Tasks that Transformers v5 removed from ``pipeline()``, implemented with the Auto classes.

These work on Transformers v4 and v5. Their results use the same shape the old pipelines returned.
"""

from __future__ import annotations

from typing import Any, Dict, List

from .qa import best_answer_span


class Summarizer:
    """Abstractive summarisation with a sequence-to-sequence model (for example BART)."""

    def __init__(self, model_id: str, device: str = "cpu") -> None:
        import torch
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

        self._torch = torch
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_id).to(device).eval()

    def __call__(self, text: str, max_new_tokens: int = 130, min_new_tokens: int = 30) -> List[Dict[str, str]]:
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=1024).to(self.device)
        with self._torch.inference_mode():
            ids = self.model.generate(
                **inputs,
                num_beams=4,
                do_sample=False,
                early_stopping=True,
                max_new_tokens=max_new_tokens,
                min_new_tokens=min_new_tokens,
            )
        return [{"summary_text": self.tokenizer.decode(ids[0], skip_special_tokens=True)}]


class ExtractiveQA:
    """Extractive question answering with a SQuAD-style model (for example DistilBERT)."""

    def __init__(self, model_id: str, device: str = "cpu") -> None:
        import torch
        from transformers import AutoModelForQuestionAnswering, AutoTokenizer

        self._torch = torch
        self.device = device
        self.tokenizer = AutoTokenizer.from_pretrained(model_id)
        self.model = AutoModelForQuestionAnswering.from_pretrained(model_id).to(device).eval()

    def __call__(self, question: str, context: str) -> Dict[str, Any]:
        encoded = self.tokenizer(
            question,
            context,
            return_tensors="pt",
            truncation="only_second",  # shorten the context, never the question
            max_length=384,
            return_offsets_mapping=True,
        )
        offsets = encoded["offset_mapping"][0].tolist()
        sequence_ids = encoded.sequence_ids(0)
        model_inputs = {k: v.to(self.device) for k, v in encoded.items() if k != "offset_mapping"}
        with self._torch.inference_mode():
            outputs = self.model(**model_inputs)
        return best_answer_span(
            outputs.start_logits[0].cpu().numpy(),
            outputs.end_logits[0].cpu().numpy(),
            offsets,
            sequence_ids,
            context,
        )
