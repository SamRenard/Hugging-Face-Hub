"""Turn raw pipeline outputs into readable lines, a JSON file and a Markdown report."""

from __future__ import annotations

import json
import platform
from dataclasses import asdict
from datetime import date
from importlib import metadata
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Set

# Pipeline task names whose availability we report to the user.
CHECKED_PIPELINE_TASKS = ("sentiment-analysis", "ner", "text-generation", "summarization", "question-answering")


def describe(spec: Any, output: Any) -> List[str]:
    """One or more human-readable lines for a task's raw output (falls back to repr if the shape differs)."""
    try:
        return _describe(spec, output)
    except (KeyError, TypeError, IndexError, ValueError):
        return [f"(unexpected output format) {repr(output)[:500]}"]


def _describe(spec: Any, output: Any) -> List[str]:
    key, example = spec.key, spec.example
    if key == "sentiment":
        return [f"{r['label']} ({r['score']:.4f})  {text}" for text, r in zip(example["texts"], output)]
    if key == "ner":
        lines: List[str] = []
        for text, entities in zip(example["texts"], output):
            lines.append(text)
            if not entities:
                lines.append("    (no entities)")
            lines.extend(f"    {e['entity_group']:<5} {e['word']}  ({e['score']:.3f})" for e in entities)
        return lines
    if key == "summarization":
        return [output[0]["summary_text"]]
    if key == "qa":
        return [f"Q: {example['question']}", f"A: {output['answer']}  (score {output['score']:.3f})"]
    if key == "generation":
        return [output[0]["generated_text"]]
    raise ValueError(f"No formatter for task {key!r}")


def environment_info() -> Dict[str, str]:
    def version(package: str) -> str:
        try:
            return metadata.version(package)
        except metadata.PackageNotFoundError:
            return "not installed"

    return {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "transformers": version("transformers"),
        "torch": version("torch"),
        "date": date.today().isoformat(),
    }


def supported_pipeline_tasks() -> Optional[Set[str]]:
    """Task names accepted by the installed ``transformers.pipeline`` (None if it cannot be determined)."""
    try:
        from transformers.pipelines import get_supported_tasks

        return set(get_supported_tasks())
    except Exception:
        return None


def _jsonable(obj: Any) -> Any:
    """json.dumps ``default=``: numpy scalars/arrays, sets and paths."""
    if hasattr(obj, "tolist"):
        return obj.tolist()
    if isinstance(obj, (set, frozenset)):
        return sorted(obj)
    return str(obj)


def to_json(results: Iterable[Any], env: Mapping[str, str]) -> str:
    rows = []
    for r in results:
        row = asdict(r)
        row["load_seconds"] = round(row["load_seconds"], 3)
        row["run_seconds"] = round(row["run_seconds"], 3)
        rows.append(row)
    return json.dumps({"environment": dict(env), "results": rows}, indent=2, ensure_ascii=False, default=_jsonable)


def to_markdown(results: Iterable[Any], env: Mapping[str, str]) -> str:
    results = list(results)
    out = ["# Pipeline results", ""]
    out.append(
        f"Python {env.get('python')} | transformers {env.get('transformers')} | torch {env.get('torch')} | "
        f"{env.get('date')}"
    )
    out += ["", "| Task | Model | API | Load (s) | Run (s) | Status |", "|---|---|---|---|---|---|"]
    for r in results:
        api = "pipeline()" if r.uses_pipeline else "Auto classes"
        status = "ok" if r.ok else "FAILED"
        out.append(f"| {r.title} | `{r.model_id}` | {api} | {r.load_seconds:.2f} | {r.run_seconds:.2f} | {status} |")
    for r in results:
        out += ["", f"## {r.title}", "", f"Model: `{r.model_id}`", ""]
        if r.ok:
            out += ["```text", *r.lines, "```"]
        else:
            out += ["```text", f"FAILED: {r.error}", "```"]
    return "\n".join(out) + "\n"


def write_reports(results: Iterable[Any], env: Mapping[str, str], out_dir: Path) -> List[Path]:
    results = list(results)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path, md_path = out_dir / "results.json", out_dir / "results.md"
    json_path.write_text(to_json(results, env), encoding="utf-8")
    md_path.write_text(to_markdown(results, env), encoding="utf-8")
    return [json_path, md_path]
