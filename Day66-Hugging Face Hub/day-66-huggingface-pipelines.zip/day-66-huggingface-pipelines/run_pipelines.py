"""Run the five Hugging Face tasks and write outputs/results.json and outputs/results.md.

    python run_pipelines.py                  # all five
    python run_pipelines.py sentiment ner    # a selection
    python run_pipelines.py --list           # show tasks and models
"""

from hf_tasks.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
