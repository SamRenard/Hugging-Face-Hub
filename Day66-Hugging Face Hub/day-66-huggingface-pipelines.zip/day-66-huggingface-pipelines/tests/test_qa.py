"""The answer-span decoder (pure NumPy, no model needed)."""

import re

import numpy as np
import pytest

from hf_tasks import best_answer_span

CONTEXT = "Paris is the capital of France"
# Tokens:   [CLS] what ?  [SEP]  Paris is the capital of France  [SEP]
SEQ_IDS = [None, 0, 0, None, 1, 1, 1, 1, 1, 1, None]
OFFSETS = [(0, 0), (0, 4), (4, 5), (0, 0)] + [m.span() for m in re.finditer(r"\w+", CONTEXT)] + [(0, 0)]
PARIS, IS, THE, CAPITAL, OF, FRANCE = 4, 5, 6, 7, 8, 9


def logits(**peaks):
    """Zero logits with chosen peaks, e.g. logits(**{"4": 10.0})."""
    out = np.zeros(len(SEQ_IDS))
    for index, value in peaks.items():
        out[int(index)] = value
    return out


def span(start, end, **kwargs):
    return best_answer_span(logits(**{str(start): 10.0}), logits(**{str(end): 10.0}), OFFSETS, SEQ_IDS, CONTEXT, **kwargs)


def test_single_token_answer():
    result = span(PARIS, PARIS)
    assert result["answer"] == "Paris" and (result["start"], result["end"]) == (0, 5)
    assert result["score"] > 0.9


def test_multi_token_answer_uses_character_offsets():
    assert span(CAPITAL, FRANCE)["answer"] == "capital of France"


def test_question_and_special_tokens_can_never_be_the_answer():
    start, end = logits(), logits()
    for i in (0, 1, 2, 3, 10):  # CLS, question tokens, SEP, final SEP get huge scores
        start[i] = end[i] = 100.0
    start[FRANCE] = end[FRANCE] = 1.0
    assert best_answer_span(start, end, OFFSETS, SEQ_IDS, CONTEXT)["answer"] == "France"


def test_end_before_start_is_never_returned():
    result = span(start=FRANCE, end=PARIS)  # the model "wants" an impossible span
    assert result["start"] <= result["end"]


def test_max_answer_tokens_limits_span_length():
    result = span(PARIS, FRANCE, max_answer_tokens=3)
    assert len(result["answer"].split()) <= 3


def test_uniform_logits_give_a_probability_of_one_over_36():
    zeros = np.zeros(len(SEQ_IDS))
    result = best_answer_span(zeros, zeros, OFFSETS, SEQ_IDS, CONTEXT)
    assert result["score"] == pytest.approx(1 / 36)  # 6 context tokens: (1/6) * (1/6)
    assert result["answer"] == "Paris"  # ties resolve to the first valid span


def test_adding_a_constant_to_the_logits_changes_nothing():
    a = best_answer_span(logits(**{"4": 3.0}), logits(**{"7": 2.0}), OFFSETS, SEQ_IDS, CONTEXT)
    b = best_answer_span(logits(**{"4": 3.0}) + 50, logits(**{"7": 2.0}) - 7, OFFSETS, SEQ_IDS, CONTEXT)
    assert a["answer"] == b["answer"] and a["score"] == pytest.approx(b["score"])


def test_accepts_plain_lists():
    result = best_answer_span([0.0] * 4 + [9.0] + [0.0] * 6, [0.0] * 4 + [9.0] + [0.0] * 6, OFFSETS, SEQ_IDS, CONTEXT)
    assert result["answer"] == "Paris"


def test_score_is_a_probability():
    rng = np.random.default_rng(0)
    for _ in range(20):
        result = best_answer_span(rng.normal(size=11), rng.normal(size=11), OFFSETS, SEQ_IDS, CONTEXT)
        assert 0.0 < result["score"] <= 1.0


def test_invalid_inputs_raise():
    ok = np.zeros(len(SEQ_IDS))
    with pytest.raises(ValueError):
        best_answer_span(ok[:-1], ok, OFFSETS, SEQ_IDS, CONTEXT)  # length mismatch
    with pytest.raises(ValueError):
        best_answer_span(ok, ok, OFFSETS, [None, 0, 0, None] + [0] * 7, CONTEXT)  # no context tokens
    with pytest.raises(ValueError):
        best_answer_span(ok, ok, OFFSETS, SEQ_IDS, CONTEXT, max_answer_tokens=0)
