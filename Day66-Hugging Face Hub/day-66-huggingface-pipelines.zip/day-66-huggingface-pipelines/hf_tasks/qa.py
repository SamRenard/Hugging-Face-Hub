"""Extractive question answering: turn start/end logits into an answer span.

``pipeline("question-answering")`` was removed in Transformers v5, so the decoding step that the
pipeline used to do is written out here in plain NumPy.

A QA model outputs, for every token, one score for "the answer starts here" and one for
"the answer ends here". We keep only context tokens, turn each score list into probabilities with a
softmax, and pick the span (i, j) with the highest ``P_start[i] * P_end[j]`` where ``j >= i`` and the
span is not too long.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Sequence, Tuple

import numpy as np


def best_answer_span(
    start_logits: Sequence[float],
    end_logits: Sequence[float],
    offsets: Sequence[Tuple[int, int]],
    sequence_ids: Sequence[Optional[int]],
    context: str,
    max_answer_tokens: int = 30,
) -> Dict[str, Any]:
    """Return ``{"answer", "score", "start", "end"}`` (character offsets into ``context``).

    Args:
        start_logits, end_logits: one score per token.
        offsets: ``(start_char, end_char)`` of every token (from ``return_offsets_mapping=True``).
        sequence_ids: ``None`` for special tokens, ``0`` for question tokens, ``1`` for context tokens
            (``BatchEncoding.sequence_ids()``).
        context: the original context string the offsets point into.
        max_answer_tokens: longest allowed answer, in tokens.
    """
    start = np.asarray(start_logits, dtype=float)
    end = np.asarray(end_logits, dtype=float)
    n = len(start)
    if not (len(end) == len(offsets) == len(sequence_ids) == n):
        raise ValueError("start_logits, end_logits, offsets and sequence_ids must have the same length")
    if max_answer_tokens < 1:
        raise ValueError("max_answer_tokens must be at least 1")

    in_context = np.array([s == 1 for s in sequence_ids])
    if not in_context.any():
        raise ValueError("The input contains no context tokens (was the context truncated away?)")

    def masked_softmax(logits: np.ndarray) -> np.ndarray:
        z = np.where(in_context, logits, -np.inf)  # question and special tokens can never be answers
        z = z - z.max()
        e = np.exp(z)
        return e / e.sum()

    scores = np.outer(masked_softmax(start), masked_softmax(end))  # scores[i, j] = P(start=i) * P(end=j)
    idx = np.arange(n)
    valid = (idx[None, :] >= idx[:, None]) & (idx[None, :] - idx[:, None] < max_answer_tokens)
    scores = np.where(valid, scores, 0.0)

    i, j = np.unravel_index(np.argmax(scores), scores.shape)
    start_char, end_char = int(offsets[i][0]), int(offsets[j][1])
    return {
        "answer": context[start_char:end_char],
        "score": float(scores[i, j]),
        "start": start_char,
        "end": end_char,
    }
