"""Five Hugging Face tasks behind one small, testable interface.

Importing this package never imports ``transformers`` or ``torch``; they are loaded lazily when a
model is actually used, so the logic can be tested without any model download.
"""

from .qa import best_answer_span
from .registry import TASKS, TaskSpec, get_task
from .runner import TaskResult, run_all, run_task

__all__ = ["TASKS", "TaskSpec", "get_task", "TaskResult", "run_task", "run_all", "best_answer_span"]
__version__ = "0.1.0"
