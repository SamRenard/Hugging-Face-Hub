"""The five tasks: which model, how it is loaded, how it is called, and an example input.

Models are pinned by name on purpose: a pipeline's *default* model can change between library
versions, which would silently change your results.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Dict, Mapping

from .direct import ExtractiveQA, Summarizer


@dataclass(frozen=True)
class TaskSpec:
    key: str  # short name used on the command line
    title: str
    pipeline_task: str  # task name for transformers.pipeline(); "" if pipeline() no longer offers it
    model_id: str
    example: Mapping[str, Any]
    load: Callable[[str, str], Any]  # (model_id, device) -> loaded object
    run: Callable[[Any, Mapping[str, Any]], Any]  # (loaded object, example) -> raw output

    @property
    def uses_pipeline(self) -> bool:
        return bool(self.pipeline_task)


# --------------------------------------------------------------------------- #
# Loaders and runners (transformers is imported lazily, inside the functions)
# --------------------------------------------------------------------------- #
def _pipeline_loader(task: str, **kwargs: Any) -> Callable[[str, str], Any]:
    def load(model_id: str, device: str) -> Any:
        from transformers import pipeline

        return pipeline(task, model=model_id, device=device, **kwargs)

    return load


def _run_on_texts(pipe: Any, example: Mapping[str, Any]) -> Any:
    return pipe(list(example["texts"]))


def _run_generation(pipe: Any, example: Mapping[str, Any]) -> Any:
    from transformers import set_seed

    set_seed(int(example.get("seed", 0)))  # makes the sampled text reproducible
    return pipe(
        example["prompt"],
        max_new_tokens=int(example.get("max_new_tokens", 40)),
        do_sample=True,
        temperature=0.8,
        top_k=50,
        pad_token_id=pipe.tokenizer.eos_token_id,
    )


def _load_summarizer(model_id: str, device: str) -> Summarizer:
    return Summarizer(model_id, device)


def _load_qa(model_id: str, device: str) -> ExtractiveQA:
    return ExtractiveQA(model_id, device)


# --------------------------------------------------------------------------- #
# Example inputs (original text written for this project)
# --------------------------------------------------------------------------- #
SUMMARY_TEXT = (
    "The Hugging Face Hub is a platform where the machine learning community shares models, datasets and "
    "demo applications. Every model lives in its own repository, so it comes with a version history, a model "
    "card that describes how it was trained and what it is good at, and the files needed to run it, such as "
    "weights, a configuration file and a tokenizer. Developers can download a checkpoint with a single line of "
    "code, and the files are cached locally so later runs start quickly. The Transformers library builds on "
    "this: it loads models from the Hub and wraps common workflows in a high level interface called a pipeline, "
    "which handles tokenization, inference and post processing together. Because thousands of checkpoints are "
    "available for text, vision and audio, beginners can try ideas in minutes, while researchers use the same "
    "hub to publish and compare their own work."
)

QA_CONTEXT = (
    "The Transformers library is developed by Hugging Face. It provides the pipeline API, which bundles a "
    "tokenizer, a model and post processing into a single call. Models are downloaded from the Hugging Face "
    "Hub and cached on the local disk. The library supports many tasks, including text classification, token "
    "classification and text generation."
)

TASKS: Dict[str, TaskSpec] = {
    spec.key: spec
    for spec in (
        TaskSpec(
            key="sentiment",
            title="Sentiment analysis",
            pipeline_task="sentiment-analysis",
            model_id="distilbert/distilbert-base-uncased-finetuned-sst-2-english",
            example={
                "texts": [
                    "I love how easy the Hugging Face Hub makes sharing models!",
                    "This tutorial was confusing and the setup kept failing.",
                    "The documentation is fine, I guess.",
                ]
            },
            load=_pipeline_loader("sentiment-analysis"),
            run=_run_on_texts,
        ),
        TaskSpec(
            key="ner",
            title="Named entity recognition",
            pipeline_task="ner",
            model_id="dslim/bert-base-NER",
            example={
                "texts": [
                    "Hugging Face was founded in New York City by Clement Delangue, Julien Chaumond and Thomas Wolf.",
                    "Satya Nadella leads Microsoft, which is headquartered in Redmond.",
                ]
            },
            # "simple" merges word pieces into whole entities (replaces the removed grouped_entities=True)
            load=_pipeline_loader("ner", aggregation_strategy="simple"),
            run=_run_on_texts,
        ),
        TaskSpec(
            key="summarization",
            title="Summarization",
            pipeline_task="",  # removed from pipeline() in Transformers v5
            model_id="sshleifer/distilbart-cnn-12-6",
            example={"text": SUMMARY_TEXT},
            load=_load_summarizer,
            run=lambda summarizer, example: summarizer(example["text"]),
        ),
        TaskSpec(
            key="qa",
            title="Question answering",
            pipeline_task="",  # removed from pipeline() in Transformers v5
            model_id="distilbert/distilbert-base-cased-distilled-squad",
            example={"question": "Which library provides the pipeline API?", "context": QA_CONTEXT},
            load=_load_qa,
            run=lambda qa, example: qa(example["question"], example["context"]),
        ),
        TaskSpec(
            key="generation",
            title="Text generation",
            pipeline_task="text-generation",
            model_id="openai-community/gpt2",
            example={"prompt": "The Hugging Face Hub is a place where", "max_new_tokens": 40, "seed": 42},
            load=_pipeline_loader("text-generation"),
            run=_run_generation,
        ),
    )
}


def get_task(key: str, tasks: Mapping[str, TaskSpec] = TASKS) -> TaskSpec:
    try:
        return tasks[key]
    except KeyError:
        raise KeyError(f"Unknown task {key!r}. Available: {', '.join(tasks)}") from None
