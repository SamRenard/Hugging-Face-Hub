"""Command line interface: ``python run_pipelines.py [tasks] [--device cpu] [--model qa=org/name]``."""

from __future__ import annotations

import argparse
import importlib.util
import sys
from pathlib import Path
from typing import Dict, List, Mapping, Optional, Sequence

from .registry import TASKS, TaskSpec
from .report import (
    CHECKED_PIPELINE_TASKS,
    environment_info,
    supported_pipeline_tasks,
    write_reports,
)
from .runner import TaskResult, run_all


def parse_overrides(items: Sequence[str], valid_keys: Sequence[str]) -> Dict[str, str]:
    """Parse ``KEY=MODEL_ID`` items, for example ``qa=deepset/roberta-base-squad2``."""
    overrides: Dict[str, str] = {}
    for item in items:
        key, sep, model_id = item.partition("=")
        if not sep or not model_id.strip():
            raise ValueError(f"--model expects KEY=MODEL_ID, got {item!r}")
        if key not in valid_keys:
            raise ValueError(f"Unknown task {key!r} in --model. Available: {', '.join(valid_keys)}")
        overrides[key] = model_id.strip()
    return overrides


def build_parser(tasks: Mapping[str, TaskSpec]) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Try five Hugging Face tasks and save a report.")
    parser.add_argument("tasks", nargs="*", metavar="TASK",
                        help=f"tasks to run (default: all). Choices: {', '.join(tasks)}")
    parser.add_argument("--device", default="cpu", help="cpu, cuda, mps, ... (default: cpu)")
    parser.add_argument("--model", action="append", default=[], metavar="KEY=MODEL_ID",
                        help="use another model for a task (repeatable)")
    parser.add_argument("--output-dir", type=Path, default=Path("outputs"))
    parser.add_argument("--list", action="store_true", help="list the tasks and their default models, then exit")
    return parser


def _print_task_support() -> None:
    if importlib.util.find_spec("transformers") is None:
        print("transformers is not installed (pip install -r requirements.txt).")
        return
    supported = supported_pipeline_tasks()
    if supported is None:
        print("Could not determine which pipeline tasks your Transformers version supports.")
        return
    print("pipeline() tasks supported by your Transformers version:")
    for task in CHECKED_PIPELINE_TASKS:
        print(f"  {task:<20} {'yes' if task in supported else 'no'}")
    if "summarization" not in supported or "question-answering" not in supported:
        print("  (removed in Transformers v5: summarization and QA run through the Auto classes here)")


def _print_result(number: int, total: int, result: TaskResult) -> None:
    status = "ok" if result.ok else "FAILED"
    print(f"[{number}/{total}] {result.title} - {result.model_id} - {status} "
          f"(load {result.load_seconds:.1f}s, run {result.run_seconds:.1f}s)")
    for line in (result.lines if result.ok else [f"FAILED: {result.error}"]):
        print(f"    {line}")
    print()


def main(argv: Optional[Sequence[str]] = None, tasks: Optional[Mapping[str, TaskSpec]] = None) -> int:
    tasks = tasks if tasks is not None else TASKS
    if hasattr(sys.stdout, "reconfigure"):  # model output may contain characters a legacy Windows console rejects
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")

    parser = build_parser(tasks)
    args = parser.parse_args(argv)

    unknown = [t for t in args.tasks if t not in tasks]
    if unknown:
        parser.error(f"unknown task(s): {', '.join(unknown)}. Choose from: {', '.join(tasks)}")
    try:
        overrides = parse_overrides(args.model, list(tasks))
    except ValueError as exc:
        parser.error(str(exc))

    if args.list:
        for spec in tasks.values():
            api = "pipeline()" if spec.uses_pipeline else "Auto classes"
            print(f"{spec.key:<14} {spec.model_id:<62} {api}")
        return 0

    _print_task_support()
    print()
    results: List[TaskResult] = run_all(args.tasks or None, tasks, args.device, overrides, _print_result)

    paths = write_reports(results, environment_info(), args.output_dir)
    failed = [r.key for r in results if not r.ok]
    print("Saved: " + ", ".join(str(p) for p in paths))
    if failed:
        print(f"{len(failed)} task(s) failed: {', '.join(failed)}")
        return 1
    print(f"All {len(results)} tasks succeeded.")
    return 0
