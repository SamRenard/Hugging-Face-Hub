"""Run tasks one by one, timing them and isolating failures."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Mapping, Optional, Sequence

from .registry import TASKS, TaskSpec, get_task


@dataclass
class TaskResult:
    key: str
    title: str
    model_id: str
    uses_pipeline: bool
    ok: bool
    load_seconds: float = 0.0
    run_seconds: float = 0.0
    output: Any = None
    lines: List[str] = field(default_factory=list)  # human-readable rendering of the output
    error: Optional[str] = None


def _error_text(exc: BaseException) -> str:
    return f"{type(exc).__name__}: {exc}"[:500]


def run_task(
    spec: TaskSpec,
    device: str = "cpu",
    model_id: Optional[str] = None,
    clock: Callable[[], float] = time.perf_counter,
) -> TaskResult:
    """Load the model, run the example, and always return a result (never raises on task errors)."""
    from .report import describe  # imported here to keep the module graph simple

    model = model_id or spec.model_id
    base = dict(key=spec.key, title=spec.title, model_id=model, uses_pipeline=spec.uses_pipeline)

    start = clock()
    try:
        loaded = spec.load(model, device)
    except Exception as exc:  # download problems, missing packages, wrong model id, ...
        return TaskResult(**base, ok=False, load_seconds=clock() - start, error=_error_text(exc))
    loaded_at = clock()

    try:
        output = spec.run(loaded, spec.example)
    except Exception as exc:
        return TaskResult(**base, ok=False, load_seconds=loaded_at - start, run_seconds=clock() - loaded_at,
                          error=_error_text(exc))
    finished = clock()
    return TaskResult(**base, ok=True, load_seconds=loaded_at - start, run_seconds=finished - loaded_at,
                      output=output, lines=describe(spec, output))


def run_all(
    keys: Optional[Sequence[str]] = None,
    tasks: Mapping[str, TaskSpec] = TASKS,
    device: str = "cpu",
    overrides: Optional[Mapping[str, str]] = None,
    on_result: Optional[Callable[[int, int, TaskResult], None]] = None,
    clock: Callable[[], float] = time.perf_counter,
) -> List[TaskResult]:
    """Run the chosen tasks (all by default). One failing task does not stop the others."""
    chosen = [get_task(k, tasks) for k in (keys or list(tasks))]
    overrides = overrides or {}
    results: List[TaskResult] = []
    for number, spec in enumerate(chosen, start=1):
        result = run_task(spec, device, overrides.get(spec.key), clock)
        results.append(result)
        if on_result:
            on_result(number, len(chosen), result)
    return results
